source ./env
PGPASSWORD=test
./bin/psql -h 192.168.31.224 -p 6432 -U test test
