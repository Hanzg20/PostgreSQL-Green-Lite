source ./env
./bin/psql -h 127.0.0.1 -p 6432 postgres
