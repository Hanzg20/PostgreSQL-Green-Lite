source ./env
PGPASSWORD=test
./bin/psql -h 127.0.0.1 -p 6432 -U test test
