source ./env
./bin/pg_ctl -D ./data -l logfile stop
